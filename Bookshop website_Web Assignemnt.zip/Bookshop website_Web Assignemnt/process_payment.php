<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process the payment
    // Add your payment processing logic here
    
    // Clear the cart after successful payment
    $_SESSION['cart'] = [];
    
    // Redirect to success page
    header('Location: payment_success.php');
    exit();
} else {
    // Redirect back to checkout if accessed directly
    header('Location: checkout.php');
    exit();
}
?>
