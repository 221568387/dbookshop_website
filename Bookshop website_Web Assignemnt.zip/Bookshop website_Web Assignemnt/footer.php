    </main>
    <footer style="background-color: var(--color-primary); color: white; padding: 1rem; text-align: center;">
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> TECH WRLD BOOKSHOP. All rights reserved.</p>
            <div class="social-media">
                <a href="https://twitter.com/yourprofile" target="_blank" style="color: white; margin: 0 10px;">
                    <i class="fab fa-twitter"></i> <!-- Twitter Icon -->
                </a>
                <a href="https://www.instagram.com/yourprofile" target="_blank" style="color: white; margin: 0 10px;">
                    <i class="fab fa-instagram"></i> <!-- Instagram Icon -->
                </a>
                <a href="https://www.facebook.com/yourprofile" target="_blank" style="color: white; margin: 0 10px;">
                    <i class="fab fa-facebook-f"></i> <!-- Facebook Icon -->
                </a>
            </div>
        </div>
    </footer>
    <script>
        window.addEventListener('scroll', function() {
            var header = document.getElementById('header');
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    </script>
</body>
</html>