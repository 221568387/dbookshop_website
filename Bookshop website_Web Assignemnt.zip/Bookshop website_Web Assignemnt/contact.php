<?php
$pageTitle = "Contact Us - TECH WRLD BOOKSHOP";
include 'header.php'; // Include your header file
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="path/to/your/styles.css"> <!-- Link to your CSS file if needed -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --color-primary: #2563eb;
            --color-secondary: #10b981;
            --color-accent: #f59e0b;
            --color-background: #f3f4f6;
            --color-text: #1f2937;
            --color-text-light: #6b7280;
        }

        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            color: var(--color-text);
            background-color: var(--color-background);
            margin: 0; /* Remove default margin */
            padding: 0; /* Remove default padding */
        }

        .container {
            width: 100%; /* Full width */
            max-width: 1200px; /* Optional: limit max width */
            margin: 0 auto; /* Center the container */
            padding: 20px; /* Add some padding */
        }

        .contact-container {
            display: flex;
            justify-content: space-between;
            margin-top: 2rem;
        }

        .contact-form, .contact-info {
            flex: 1;
            background-color: white;
            padding: 2rem;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-right: 2rem; /* Space between form and info */
        }

        .contact-info {
            margin-right: 0; /* No margin on the last column */
        }

        .form-group {
            margin-bottom: 1rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
        }

        input, textarea {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        textarea {
            height: 150px;
        }

        button {
            background-color: var(--color-primary);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: var(--color-primary-light);
        }

        .success-message, .error-message {
            margin-top: 1rem;
            padding: 0.5rem;
            border-radius: 3px;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
        }

        .cta-section {
            background-color: var(--color-primary);
            color: white;
            text-align: center;
            padding: 2rem;
            margin-top: 2rem;
        }

        .cta-button {
            background-color: white;
            color: var(--color-primary);
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .cta-button:hover {
            background-color: #e3a008;
        }

        /* Google Map Styles */
        .map-container {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Contact Us</h1>
        <p>If you have any questions, comments, or concerns, please feel free to reach out to us!</p>

        <div class="contact-container">
            <div class="contact-form">
                <h2>Send us a message</h2>
                <form id="contact-form" method="POST" action="">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="subject">Subject</label>
                        <input type="text" id="subject" name="subject" required>
                    </div>
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea id="message" name="message" required></textarea>
                    </div>
                    <button type="submit">Send Message</button>
                </form>
                <div class="success-message" id="success-message" style="display:none;">Your message has been sent successfully!</div>
                <div class="error-message" id="error-message" style="display:none;">There was an error sending your message. Please try again.</div>
            </div>

            <div class="contact-info">
                <h2>Get in Touch</h2>
                <div class="contact-method">
                    <span>📞 (123) 456-7890</span>
                </div>
                <div class="contact-method">
                    <span>✉️ info@techwrldbooks.com</span>
                </div>
                <div class="contact-method">
                    <span>🏠 1911 Vanderbijlpark, Shakesphear, RC 12345</span>
                </div>

                <!-- Google Map Embed for Gauteng Province, South Africa -->
                <div class="map-container">
                    <a href="https://www.google.com/maps/place/Gauteng,+South+Africa" target="_blank" style="display: inline-block; width: 100%; max-width: 600px;">
                        <iframe 
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d155123.123456789!2d28.047568!3d-26.204102!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e950b1c1c1c1c1d%3A0x1c1c1c1c1c1c1c1!2sGauteng%2C+South+Africa!5e0!3m2!1sen!2sus!4v1616161616161!5m2!1sen!2sus" 
                            width="600" 
                            height="450" 
                            style="border:0;" 
                            allowfullscreen="" 
                            loading="lazy">
                        </iframe>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $subject = $_POST['subject'];
        $message = $_POST['message'];

        // Here you would typically send the message to your email or store it in a database
        // For demonstration, we will just show a success message
        echo "<script>document.getElementById('success-message').style.display = 'block';</script>";
    }
    ?>

    <?php include 'footer.php'; ?>
</body>
</html>