<?php
session_start();
header('Content-Type: application/json');

// Retrieve the posted data
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['id'], $data['title'], $data['price'])) {
    // Initialize the cart if it doesn't exist
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Add the item to the session cart
    $_SESSION['cart'][] = [
        'id' => $data['id'],
        'title' => $data['title'],
        'price' => (float)$data['price']
    ];

    echo json_encode(['status' => 'success', 'message' => 'Item added to cart']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid data provided']);
}
?>
