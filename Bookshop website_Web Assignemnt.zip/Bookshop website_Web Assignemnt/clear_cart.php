<?php
session_start();

// Clear the cart session
$_SESSION['cart'] = [];

// Return a JSON response
echo json_encode(['status' => 'success']);
?>
