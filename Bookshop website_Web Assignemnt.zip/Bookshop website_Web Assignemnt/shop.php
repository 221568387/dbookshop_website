<?php
session_start();
include 'db.php';
$pageTitle = "Shop - TECH WRLD BOOKSHOP";

// Clear the cart on page refresh
if (!isset($_SESSION['last_activity']) || (time() - $_SESSION['last_activity'] > 1)) {
    $_SESSION['cart'] = [];
}
$_SESSION['last_activity'] = time();

// Fetch books from the database
$books = [];
$stmt = $conn->prepare("SELECT id, title, author, price, cover_image, description FROM books LIMIT 15");
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $books[] = $row;
}

$stmt->close();

// Convert PHP array to JSON for use in JavaScript
$booksJson = json_encode($books);

// Include the header
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <style>
        :root {
            --primary-color: #4a4e69;
            --secondary-color: #9a8c98;
            --background-color: #f2e9e4;
            --text-color: #22223b;
            --button-color: #d6a600;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--background-color);
            color: var(--text-color);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }

        main {
            max-width: 1200px;
            margin: 0 auto;
            padding: 80px 1rem 2rem; /* Adjusted top padding to account for fixed header */
        }

        .cart-icon {
            position: fixed;
            top: 15px; /* Adjusted to align with header */
            right: 20px;
            background-color: var(--button-color);
            color: white;
            padding: 10px;
            border-radius: 50%;
            cursor: pointer;
            z-index: 1001; /* Ensure it's above the header */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        .cart-count {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: var(--primary-color);
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 0.8rem;
        }

        .book-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }

        .book-card {
            position: relative;
            overflow: hidden; /* Prevent overflow during animation */
            transition: transform 0.3s ease; /* Add transition for card hover effect */
            margin: 1rem;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 1rem;
            background-color: white;
        }

        .book-card:hover {
            transform: scale(1.05); /* Slightly scale up the card on hover */
        }

        .book-image {
            width: 100%;
            height: 300px;
            object-fit: cover;
        }

        .book-info {
            padding: 1rem;
        }

        .book-title {
            font-size: 1.2rem;
            margin-bottom: 0.5rem;
        }

        .book-author {
            color: var(--secondary-color);
            margin-bottom: 0.5rem;
        }

        .book-price {
            font-weight: bold;
            margin-bottom: 1rem;
        }

        .book-description {
            font-size: 0.9rem;
            margin-bottom: 1rem;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .add-to-cart {
            background-color: var(--button-color);
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .add-to-cart:hover {
            background-color: #b59400;
        }

        .cart-modal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            border: 2px solid var(--secondary-color);
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            z-index: 1002;
            padding: 1rem;
            max-width: 400px;
            width: 100%;
        }

        .cart-modal h2 {
            margin-bottom: 1rem;
        }

        .cart-modal ul {
            list-style-type: none;
            padding: 0;
            margin-bottom: 1rem;
        }

        .cart-modal li {
            margin-bottom: 0.5rem;
        }

        .cart-modal .total {
            font-weight: bold;
            margin-top: 1rem;
        }

        .close-modal, .clear-cart, .proceed-checkout {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 0.5rem;
        }

        .close-modal:hover, .clear-cart:hover, .proceed-checkout:hover {
            background-color: #b59400;
        }

        .featured-books {
            margin: 2rem 0;
        }

        .preview {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .preview-item {
            width: 30%;
            margin: 10px;
            text-align: center;
        }

        .preview-item img {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }

        @media (max-width: 768px) {
            .cart-icon {
                top: 10px;
                right: 10px;
            }

            .preview-item {
                width: 100%; /* Stack items on smaller screens */
                margin: 5px 0; /* Adjust margin */
            }
        }

        .book-details {
            max-height: 0; /* Start with a height of 0 */
            overflow: hidden; /* Hide overflow */
            transition: max-height 0.3s ease, opacity 0.3s ease; /* Transition for height and opacity */
            opacity: 0; /* Start with opacity 0 */
        }

        .book-details.show {
            max-height: 200px; /* Set a max height for the expanded state */
            opacity: 1; /* Fade in the details */
        }

        .bookshelf-title {
            text-align: center; /* Center the text */
            margin: 20px 0; /* Add some margin for spacing */
            font-size: 2rem; /* Adjust font size as needed */
            color: var(--text-color); /* Optional: Set the text color */
        }
    </style>
</head>
<body>
    <!-- Cart Icon -->
    <div class="cart-icon" id="cart-icon">
        🛒
        <span class="cart-count" id="cart-count"><?php echo count($_SESSION['cart']); ?></span>
    </div>

    <main>
        <div class="book-grid">
            <?php foreach ($books as $book): ?>
                <div class="book-card" data-id="<?php echo $book['id']; ?>">
                    <img src="<?php echo htmlspecialchars($book['cover_image']); ?>" alt="<?php echo htmlspecialchars($book['title']); ?>" class="book-image">
                    <div class="book-info">
                        <h2 class="book-title"><?php echo htmlspecialchars($book['title']); ?></h2>
                        <p class="book-author"><?php echo htmlspecialchars($book['author']); ?></p>
                        <p class="book-price">R<?php echo number_format($book['price'], 2); ?></p>
                        <button class="add-to-cart" data-id="<?php echo $book['id']; ?>">Add to Cart</button>
                        <button class="toggle-details">Details</button>
                    </div>
                    <div class="book-details" style="display: none;">
                        <p><?php echo htmlspecialchars($book['description']); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Cart Modal -->
        <div class="cart-modal" id="cart-modal" style="display: none;">
            <h2>Cart Items</h2>
            <ul id="cart-items"></ul>
            <p class="total" id="total-amount">Total: R0.00</p>
            <button class="close-modal" id="close-modal">Close</button>
            <button class="clear-cart" id="clear-cart">Clear Cart</button>
            <button class="proceed-checkout" id="proceed-checkout" onclick="window.location.href='checkout.php'">Proceed to Checkout</button>
        </div>

        <!-- Featured Books Section -->
        <section class="featured-books section">
            <div class="container">
            <h3 class="bookshelf-title">BookShelf</h3>
                <div class="preview">
                    <div class="preview-item">
                        <img src="images/computer-science.jpg" alt="Computer Science" />
                        <h3>Computer Science</h3>
                        <p>Discussing algorithms, programming, and sequential and parallel processing.</p>
                        <p class="book-price">R299.99</p>
                        <button class="add-to-cart" data-id="1" data-title="Computer Science" data-price="299.99">Add to Cart</button>
                    </div>
                    <div class="preview-item">
                        <img src="images/database-concepts.jpg" alt="Database Concepts" />
                        <h3>Database Concepts</h3>
                        <p>The book discusses concepts, principles, design, implementation, and management issues of databases.</p>
                        <p class="book-price">R249.99</p>
                        <button class="add-to-cart" data-id="2" data-title="Database Concepts" data-price="249.99">Add to Cart</button>
                    </div>
                    <div class="preview-item">
                        <img src="images/code-complete.jpg" alt="Code Complete" />
                        <h3>Code Complete</h3>
                        <p>Extensive exploration of clean coding principles and agile practices.</p>
                        <p class="book-price">R399.99</p>
                        <button class="add-to-cart" data-id="3" data-title="Code Complete" data-price="399.99">Add to Cart</button>
                    </div>
                    <div class="preview-item">
                        <img src="images/clean-code.jpg" alt="Clean Code" />
                        <h3>Clean Code</h3>
                        <p>A Handbook of Agile Software Craftsmanship.</p>
                        <p class="book-price">R299.99</p>
                        <button class="add-to-cart" data-id="4" data-title="Clean Code" data-price="299.99">Add to Cart</button>
                    </div>
                    <div class="preview-item">
                        <img src="images/the-pragmatic-programmer.jpg" alt="The Pragmatic Programmer" />
                        <h3>The Pragmatic Programmer</h3>
                        <p>Your Journey to Mastery.</p>
                        <p class="book-price">R349.99</p>
                        <button class="add-to-cart" data-id="5" data-title="The Pragmatic Programmer" data-price="349.99">Add to Cart</button>
                    </div>
                    <div class="preview-item">
                        <img src="images/design-patterns.jpg" alt="Design Patterns" />
                        <h3>Design Patterns</h3>
                        <p>Elements of Reusable Object-Oriented Software.</p>
                        <p class="book-price">R399.99</p>
                        <button class="add-to-cart" data-id="6" data-title="Design Patterns" data-price="399.99">Add to Cart</button>
                    </div>
                    <div class="preview-item">
                        <img src="images/introduction-to-algorithms.jpg" alt="Introduction to Algorithms" />
                        <h3>Introduction to Algorithms</h3>
                        <p>Comprehensive guide to algorithms.</p>
                        <p class="book-price">R499.99</p>
                        <button class="add-to-cart" data-id="7" data-title="Introduction to Algorithms" data-price="499.99">Add to Cart</button>
                    </div>
                    <div class="preview-item">
                        <img src="images/you-dont-know-js.jpg" alt="You Don't Know JS" />
                        <h3>You Don't Know JS</h3>
                        <p>Scope & Closures.</p>
                        <p class="book-price">R199.99</p>
                        <button class="add-to-cart" data-id="8" data-title="You Don't Know JS" data-price="199.99">Add to Cart</button>
                    </div>
                    <div class="preview-item">
                        <img src="images/javascript-the-good-parts.jpg" alt="JavaScript: The Good Parts" />
                        <h3>JavaScript: The Good Parts</h3>
                        <p>Unearthing the Excellence in JavaScript.</p>
                        <p class="book-price">R249.99</p>
                        <button class="add-to-cart" data-id="9" data-title="JavaScript: The Good Parts" data-price="249.99">Add to Cart</button>
                    </div>
                    <div class="preview-item">
                        <img src="images/learning-python.jpg" alt="Learning Python" />
                        <h3>Learning Python</h3>
                        <p>Powerful Object-Oriented Programming.</p>
                        <p class="book-price">R299.99</p>
                        <button class="add-to-cart" data-id="10" data-title="Learning Python" data-price="299.99">Add to Cart</button>
                    </div>
                    <div class="preview-item">
                        <img src="images/advanced-css.jpg" alt="Advanced CSS" />
                        <h3>Advanced CSS</h3>
                        <p>Mastering CSS for modern web design.</p>
                        <p class="book-price">R349.99</p>
                        <button class="add-to-cart" data-id="11" data-title="Advanced CSS" data-price="349.99">Add to Cart</button>
                    </div>
                    <div class="preview-item">
                        <img src="images/react-js.jpg" alt="React JS" />
                        <h3>React JS</h3>
                        <p>Building user interfaces with React.</p>
                        <p class="book-price">R399.99</p>
                        <button class="add-to-cart" data-id="12" data-title="React JS" data-price="399.99">Add to Cart</button>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        const books = <?php echo $booksJson; ?>;
        let cart = <?php echo json_encode($_SESSION['cart']); ?>;

        function updateCartCount() {
            const cartCount = document.getElementById('cart-count');
            cartCount.textContent = cart.length;
        }

        function addToCart(bookId, title, price) {
            fetch('add_to_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: bookId, title: title, price: price })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    alert(`${title} has been added to your cart!`);
                    cart.push({ id: bookId, title: title, price: price });
                    updateCartCount();
                } else {
                    alert("There was an issue adding the book to your cart.");
                }
            })
            .catch(error => console.error('Error:', error));
        }

        function showCart() {
            const cartModal = document.getElementById('cart-modal');
            const cartItems = document.getElementById('cart-items');
            const totalAmount = document.getElementById('total-amount');

            cartItems.innerHTML = '';
            let total = 0;

            cart.forEach(item => {
                const li = document.createElement('li');
                li.textContent = `${item.title} - R${parseFloat(item.price).toFixed(2)}`;
                cartItems.appendChild(li);
                total += parseFloat(item.price);
            });

            totalAmount.textContent = `Total: R${total.toFixed(2)}`;
            cartModal.style.display = 'block';
        }

        function clearCart() {
            fetch('clear_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    cart = [];
                    updateCartCount();
                    document.getElementById('cart-items').innerHTML = '';
                    document.getElementById('total-amount').textContent = 'Total: R0.00';
                    alert("Your cart has been cleared.");
                } else {
                    alert("There was an issue clearing the cart.");
                }
            })
            .catch(error => console.error('Error:', error));
        }

        function showCheckout() {
            window.location.href = 'checkout.php';
        }

        document.getElementById('cart-icon').addEventListener('click', showCart);
        document.getElementById('close-modal').addEventListener('click', function() {
            document.getElementById('cart-modal').style.display = 'none';
        });

        document.getElementById('clear-cart').addEventListener('click', clearCart);
        document.getElementById('proceed-checkout').addEventListener('click', showCheckout);

        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.add-to-cart').forEach(button => {
                button.addEventListener('click', function() {
                    const bookId = parseInt(this.getAttribute('data-id'));
                    const title = this.getAttribute('data-title');
                    const price = parseFloat(this.getAttribute('data-price'));
                    addToCart(bookId, title, price);
                });
            });
        });

        // Add this to your window click handler
        window.onclick = function(event) {
            const processingModal = document.getElementById('paymentProcessingModal');
            if (event.target == processingModal) {
                // Prevent closing while processing
                const processingMessage = document.querySelector('.processing-message');
                if (processingMessage.style.display === 'flex') {
                    return;
                }
                // Only allow closing after success message is shown
                processingModal.style.display = 'none';
                setTimeout(() => {
                    document.querySelector('.processing-message').style.display = 'flex';
                    document.querySelector('.success-message').style.display = 'none';
                }, 500);
            }
        }

        // Event listener for toggling book details
        bookGrid.addEventListener('click', function(event) {
            if (event.target.classList.contains('toggle-details')) {
                const bookCard = event.target.closest('.book-card');
                const bookDetails = bookCard.querySelector('.book-details');

                // Toggle the 'show' class to animate the details
                bookDetails.classList.toggle('show');
            }
        });
    </script>
</body>
</html>