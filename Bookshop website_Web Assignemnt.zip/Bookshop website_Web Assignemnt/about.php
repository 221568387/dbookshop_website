<?php
session_start();
include 'db.php';
$pageTitle = "About Us - TECH WRLD BOOKSHOP";
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .about-section {
            background-color: white;
            padding: 2rem;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
        }
        .about-image {
            width: 100%;
            max-width: 600px; /* Set a maximum width for the image */
            height: auto; /* Maintain aspect ratio */
            border-radius: 5px;
            margin-bottom: 2rem;
        }
        .mission-vision {
            display: flex;
            justify-content: space-between;
            margin-top: 2rem;
        }
        .mission, .vision {
            flex: 1;
            background-color: var(--color-background);
            padding: 1.5rem;
            border-radius: 5px;
            margin: 0 1rem;
            text-align: center; /* Center text */
        }
        .mission-icon, .vision-icon {
            font-size: 2rem; /* Icon size */
            margin-bottom: 1rem; /* Space between icon and text */
            color: var(--color-primary); /* Icon color */
        }
        .main-footer {
            background-color: var(--primary-color);
            color: white;
            padding: 40px 0 0 0;
            margin-top: 40px;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            padding: 0 20px;
        }

        .footer-section h3 {
            color: white;
            margin-bottom: 20px;
            font-size: 1.2rem;
        }

        .footer-section ul {
            list-style: none;
            padding: 0;
        }

        .footer-section ul li {
            margin-bottom: 10px;
        }

        .footer-section a {
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-section a:hover {
            color: var(--button-color);
        }

        .footer-bottom {
            text-align: center;
            padding: 20px;
            margin-top: 40px;
            background-color: rgba(0, 0, 0, 0.1);
        }

        @media (max-width: 768px) {
            .footer-content {
                grid-template-columns: 1fr;
                text-align: center;
            }
            
            .footer-section {
                padding: 0 20px;
            }
        }
    </style>
</head>

<section class="about-section">
    <h1>About TECH WRLD BOOKSHOP</h1>
    <img src="images/about.png" alt="TECH WRLD BOOKSHOP" class="about-image">
    <p>At TECH WRLD BOOKSHOP, our primary goal is to provide a comprehensive online platform where clients can easily browse and purchase a wide range of computer science books. We understand that the world of technology is constantly evolving, and we strive to keep our inventory up-to-date with the latest publications, covering various topics such as programming languages, software development, data science, artificial intelligence, and more.</p>

    <p>Our collection is carefully curated to cater to the needs of students, professionals, and tech enthusiasts alike. Whether you are a beginner looking to learn the fundamentals or an experienced developer seeking advanced resources, we have something for everyone. In addition to books, we also offer a selection of tech gadgets and accessories that complement your learning experience.</p>

    <p>To enhance your shopping experience, we provide detailed descriptions, reviews, and recommendations for each product, helping you make informed decisions. Our user-friendly website allows for seamless navigation, making it easy to find exactly what you need.</p>

    <p>We are committed to customer satisfaction, which is why we offer delivery services to your preferred location. Whether you are at home, in the office, or on campus, you can count on us to deliver your orders promptly and securely. Our goal is to empower individuals in their learning journey by making high-quality educational resources accessible to all.</p>

    <p>Join us at TECH WRLD BOOKSHOP and explore the vast world of computer science literature. Together, we can foster a community of lifelong learners and innovators, ready to tackle the challenges of the digital age.</p>

    <div class="mission-vision">
        <div class="mission">
            <i class="fas fa-book mission-icon"></i> <!-- Mission Icon -->
            <h2>Our Mission</h2>
            <p>To provide accessible, high-quality computer science and technology literature to empower individuals in their learning and professional growth. We recognize that education is a lifelong journey, and we are dedicated to making learning resources available to everyone, regardless of their background or experience level. By curating a diverse selection of books and materials, we aim to cater to the unique needs of students, educators, and professionals alike. Our commitment extends beyond just providing resources; we strive to create a supportive community where individuals can seek guidance, share knowledge, and inspire one another to reach their full potential in the ever-evolving tech landscape.</p>
        </div>
        <div class="vision">
            <i class="fas fa-lightbulb vision-icon"></i> <!-- Vision Icon -->
            <h2>Our Vision</h2>
            <p>To become the leading online platform for tech-related books and resources, fostering a community of lifelong learners and innovators. We believe that knowledge is a powerful tool that can drive change and innovation. By providing a diverse range of educational materials, we aim to inspire individuals to pursue their passions in technology and to stay ahead in an ever-evolving industry. Our platform not only serves as a marketplace for books but also as a hub for collaboration, where learners can connect, share ideas, and support one another in their educational journeys. We are dedicated to creating an inclusive environment that encourages curiosity, creativity, and the pursuit of excellence in the field of technology.</p>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>

