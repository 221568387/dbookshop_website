<?php
// db.php

// Database connection parameters
$servername = "localhost:3307"; // Use the new port number
$username = "root"; // Default username for XAMPP
$password = ""; // Default password is empty for XAMPP
$dbname = "tech_wrld"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optionally, you can set the character set for the connection
$conn->set_charset("utf8"); // This is useful for handling special characters

// Function to fetch featured books
function getFeaturedBooks($conn) {
    $sql = "SELECT title, description, image FROM books WHERE featured = 1"; // Adjust the query as needed
    $result = $conn->query($sql);
    $books = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $books[] = $row;
        }
    }
    return $books;
}

// Function to fetch customer reviews
function getCustomerReviews($conn) {
    $sql = "SELECT name, review, rating FROM reviews"; // Adjust the query as needed
    $result = $conn->query($sql);
    $reviews = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $reviews[] = $row;
        }
    }
    return $reviews;
}

// Close the connection when done
function closeConnection($conn) {
    $conn->close();
}

// Example usage (uncomment to use)
// $featuredBooks = getFeaturedBooks($conn);
// $customerReviews = getCustomerReviews($conn);

// Close the connection at the end of your script
// closeConnection($conn); // Uncomment this if you want to close the connection at the end of the script
?>
