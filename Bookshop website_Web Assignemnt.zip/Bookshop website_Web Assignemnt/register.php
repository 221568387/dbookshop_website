<?php
include 'db.php'; // Include your database connection
$pageTitle = "Register - TECH WRLD BOOKSHOP";
include 'header.php'; // Include your header

// Initialize variables for error and success messages
$error = '';
$success = '';

// Handle form submission via AJAX
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['regUsername'];
    $email = $_POST['regEmail'];
    $password = $_POST['regPassword'];
    $confirmPassword = $_POST['regConfirmPassword'];

    // Validate input
    if (empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
        $error = "All fields are required.";
    } elseif ($password !== $confirmPassword) {
        $error = "Passwords do not match.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format."; // Validate email format
    } else {
        // Check if the username already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Username already taken. Please choose a different username.";
        } else {
            // Hash the password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Prepare and execute the SQL statement to insert the new user
            $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $hashedPassword);

            if ($stmt->execute()) {
                $success = "Registration successful! You can now log in.";
                // Clear the form fields after successful registration
                $username = '';
                $email = '';
                $password = '';
                $confirmPassword = '';
            } else {
                // Handle error (e.g., email already exists)
                $error = "Error: " . $stmt->error;
            }
        }

        $stmt->close();
    }

    // Return response as JSON
    echo json_encode(['success' => $success, 'error' => $error]);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="styles.css">
    <script>
        function openRegisterModal(event) {
            event.preventDefault(); // Prevent the default link behavior
            document.getElementById('registerModal').style.display = 'block';
        }

        function closeRegisterModal() {
            document.getElementById('registerModal').style.display = 'none';
        }

        // Function to clear the form fields
        function clearFormFields() {
            document.getElementById('regUsername').value = '';
            document.getElementById('regEmail').value = '';
            document.getElementById('regPassword').value = '';
            document.getElementById('regConfirmPassword').value = '';
        }

        // AJAX form submission
        function submitRegistrationForm(event) {
            event.preventDefault(); // Prevent the default form submission

            var formData = new FormData(document.getElementById('registerForm'));

            fetch('register.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                // Clear previous messages
                document.getElementById('errorMessage').innerText = '';
                document.getElementById('successMessage').innerText = '';

                if (data.success) {
                    // Display success message with a tick icon
                    document.getElementById('successMessage').innerHTML = '<span style="color: green;">&#10003;</span> ' + data.success;
                    clearFormFields(); // Clear fields on success
                } else if (data.error) {
                    document.getElementById('errorMessage').innerText = data.error;
                }
            })
            .catch(error => console.error('Error:', error));
        }
    </script>
    <style>
        .success-message {
            color: green;
            margin-bottom: 10px;
        }
        .error-message {
            color: red;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <!-- Login Modal -->
    <div id="loginModal">
        <!-- Your login form here -->
        <a href="#" onclick="openRegisterModal(event)">Register</a> <!-- Pass event to the function -->
    </div>

    <!-- Registration Modal -->
    <div id="registerModal" style="display:none;">
        <div class="modal-content">
            <span onclick="closeRegisterModal()" class="close-button">&times;</span>
            <h2>Register</h2>
            <div id="errorMessage" class="error-message"></div>
            <div id="successMessage" class="success-message"></div>
            <form id="registerForm" onsubmit="submitRegistrationForm(event)">
                <div class="form-group">
                    <label for="regUsername">Username</label>
                    <input type="text" name="regUsername" id="regUsername" placeholder="Choose a username" required>
                </div>
                <div class="form-group">
                    <label for="regEmail">Email</label>
                    <input type="email" name="regEmail" id="regEmail" placeholder="Enter your email" required>
                </div>
                <div class="form-group">
                    <label for="regPassword">Password</label>
                    <input type="password" name="regPassword" id="regPassword" placeholder="Choose a password" required>
                </div>
                <div class="form-group">
                    <label for="regConfirmPassword">Confirm Password</label>
                    <input type="password" name="regConfirmPassword" id="regConfirmPassword" placeholder="Confirm your password" required>
                </div>
                <button type="submit" class="register-button">Register</button>
            </form>
        </div>
    </div>

    <?php include 'footer.php'; // Include your footer ?>
</body>
</html>
