<?php
session_start();
include 'db.php';
$pageTitle = "Welcome to TECH WRLD BOOKSHOP";


$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['username'] = $username;
            header("Location: shop.php");
            exit();
        } else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "Invalid username or password.";
    }

    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $username = $_POST['regUsername'];
    $email = $_POST['regEmail'];
    $password = $_POST['regPassword'];
    $confirmPassword = $_POST['regConfirmPassword'];

    if (empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
        $error = "All fields are required.";
    } elseif ($password !== $confirmPassword) {
        $error = "Passwords do not match.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Username already taken. Please choose a different username.";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $hashedPassword);

            if ($stmt->execute()) {
                $success = "Account created successfully! You can now login.";
            } else {
                $error = "Error: " . $stmt->error;
            }
        }

        $stmt->close();
    }

    echo json_encode(['success' => $success, 'error' => $error]);
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --color-primary: #1e40af;
            --color-primary-light: #3b82f6;
            --color-background: #f0f4f8;
            --color-text: #1f2937;
            --color-text-light: #6b7280;
            --color-accent: #f59e0b;
        }
        
        body, html {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--color-background);
            color: var(--color-text);
            line-height: 1.6;
        }
        
        header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background-color: #2563eb !important; /* Added !important to prevent color change */
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 1rem;
            width: 100%;
        }
        
        /* Remove the scrolled class to prevent color change */
        /* header.scrolled {
            background-color: rgba(30, 64, 175, 0.9);
        } */
        
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .logo {
            text-decoration: none;
            display: flex;
            align-items: center;
        }
        
        .logo img {
            height: 100px;
            width: auto;
            margin: -30px 0;
            transition: transform 0.3s ease;
        }
        
        .logo img:hover {
            transform: scale(1.05);
        }
        
        nav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            display: flex;
        }
        
        nav ul li {
            margin-left: 1.5rem;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: opacity 0.3s ease;
        }
        
        nav ul li a:hover {
            opacity: 0.8;
        }
        
        .login-button {
            background-color: var(--color-accent);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            display: flex;
            align-items: center;
            transition: background-color 0.3s ease;
        }
        
        .login-button:hover {
            background-color: #d68a00;
        }
        
        .login-button i {
            margin-right: 5px;
        }
        
        main {
            padding-top: 80px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        @media (max-width: 768px) {
            nav {
                flex-direction: column;
                align-items: flex-start;
            }
            nav ul {
                margin-top: 1rem;
            }
            nav ul li {
                margin-left: 0;
                margin-right: 1rem;
            }
        }

        :root {
            --color-primary: #2563eb;
            --color-secondary: #10b981;
            --color-accent: #f59e0b;
            --color-background: #f3f4f6;
            --color-text: #1f2937;
            --color-text-light: #6b7280;
        }

        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            color: var(--color-text);
            background-color: var(--color-background);
            margin: 0;
            padding: 0;
            background-image: url('images/your-background-image.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            overflow-x: hidden;
        }

        .container {
            max-width: 1200px;
            width: 100%;
            margin: 0 auto;
            padding: 0;
        }

        .hero {
            background-image: url('images/hero-background.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            min-height: 100vh;
            height: 100%;
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            position: relative;
            text-align: center;
            overflow: hidden;
            padding: 80px 20px;
            margin-top: -60px;
        }

        .hero-content {
            max-width: 800px;
            z-index: 1;
            padding: 0 1rem;
        }

        .get-started {
            padding: 10px 20px;
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
            border: none;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        section {
            padding: 50px;
            background-color: #f4f4f4;
        }

        .cta-button {
            display: inline-block;
            background-color: var(--color-accent);
            color: white;
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .cta-button:hover {
            background-color: #e3a008;
        }

        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }

        .feature {
            background-color: white;
            padding: 2rem;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .feature-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--color-primary);
        }

        .preview {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
        }

        .preview-item {
            background-color: white;
            padding: 1rem;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .preview-item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 1rem;
        }

        .reviews {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }

        .review-item {
            background-color: white;
            padding: 2rem;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .review-icon {
            font-size: 2rem;
            color: var(--color-accent);
            margin-bottom: 1rem;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 400px;
            max-width: 90%;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            text-align: left;
        }

        .form-group input {
            width: calc(100% - 20px);
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: block;
            margin-top: 0;
        }

        .button {
            background-color: #FFC107;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #388E3C;
        }

        .register-link {
            display: block;
            margin-top: 10px;
            text-align: center;
            color: var(--color-primary);
            text-decoration: none;
        }

        .register-link:hover {
            text-decoration: underline;
        }

        .success-message {
            color: green;
            margin-bottom: 10px;
        }

        .error-message {
            color: red;
            margin-bottom: 10px;
        }

        #loginRequiredModal .modal-content {
            text-align: center;
            padding: 30px;
            border-radius: 8px;
            max-width: 400px;
            margin: auto;
        }

        #loginRequiredModal h2 {
            color: #e74c3c;
            margin-bottom: 20px;
        }

        #loginRequiredModal p {
            margin: 20px 0;
            font-size: 16px;
            color: #333;
        }

        #loginRequiredModal button {
            background-color: var(--color-primary);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 15px;
            transition: background-color 0.3s ease;
        }

        #loginRequiredModal button:hover {
            background-color: #1e40af;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .shop-now-btn {
            display: inline-block;
            padding: 12px 24px;
            background-color: var(--color-primary);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            font-size: 16px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            text-align: center;
            margin: 10px 0;
        }

        .shop-now-btn:hover {
            background-color: #1e40af;
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .shop-now-btn:active {
            transform: translateY(0);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        /* Match other buttons for consistency */
        .button, 
        .shop-now-btn {
            display: inline-block;
            padding: 12px 24px;
            background-color: var(--color-primary);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            font-size: 16px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            text-align: center;
            margin: 10px 0;
        }

        .button:hover,
        .shop-now-btn:hover {
            background-color: #1e40af;
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .button:active,
        .shop-now-btn:active {
            transform: translateY(0);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        #registrationSuccessModal .modal-content {
            text-align: center;
            padding: 30px;
            max-width: 400px;
        }

        #registrationSuccessModal .success-message {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
        }

        #registrationSuccessModal i {
            font-size: 48px;
            color: #4CAF50;
        }

        #registrationSuccessModal h2 {
            color: #4CAF50;
            margin: 10px 0;
        }

        #registrationSuccessModal p {
            color: #666;
            margin-bottom: 20px;
        }

        #registrationSuccessModal .button {
            background-color: var(--color-primary);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        #registrationSuccessModal .button:hover {
            background-color: #1e40af;
        }

        /* Add these footer styles to your existing CSS */
        .main-footer {
            background-color: var(--primary-color);
            color: white;
            padding: 40px 0 0 0;
            margin-top: 40px;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            padding: 0 20px;
        }

        .footer-section h3 {
            color: white;
            margin-bottom: 20px;
            font-size: 1.2rem;
        }

        .footer-section ul {
            list-style: none;
            padding: 0;
        }

        .footer-section ul li {
            margin-bottom: 10px;
        }

        .footer-section a {
            color: white;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-section a:hover {
            color: var(--button-color);
        }

        .footer-bottom {
            text-align: center;
            padding: 20px;
            margin-top: 40px;
            background-color: rgba(0, 0, 0, 0.1);
        }

        @media (max-width: 768px) {
            .footer-content {
                grid-template-columns: 1fr;
                text-align: center;
            }
            
            .footer-section {
                padding: 0 20px;
            }
        }

        /* Add these styles near the top of your existing style block */
        header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background-color: #2563eb !important; /* Blue color with !important to override any other styles */
            z-index: 1000;
            transition: none !important; /* Disable any transitions */
        }

        /* Override any scroll-based classes */
        header.scrolled,
        header.header-scrolled {
            background-color: #2563eb !important;
            backdrop-filter: none !important;
            -webkit-backdrop-filter: none !important;
        }

        /* Ensure header links remain visible */
        header a,
        header.scrolled a,
        header.header-scrolled a {
            color: white !important;
        }


        }
    </style>
    <script>
        function openRegisterModal(event) {
            event.preventDefault();
            document.getElementById('registerModal').style.display = 'block';
        }

        function closeRegisterModal() {
            document.getElementById('registerModal').style.display = 'none';
        }

        function clearFormFields() {
            document.getElementById('regUsername').value = '';
            document.getElementById('regEmail').value = '';
            document.getElementById('regPassword').value = '';
            document.getElementById('regConfirmPassword').value = '';
        }

        function submitRegistrationForm(event) {
            event.preventDefault();

            var formData = new FormData(document.getElementById('registerForm'));
            formData.append('register', '1');

            fetch('index.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                document.getElementById('errorMessage').innerText = '';
                document.getElementById('successMessage').innerText = '';

                if (data.success) {
                    document.getElementById('successMessage').innerHTML = '<span style="color: green;">&#10003;</span> ' + data.success;
                    clearFormFields();
                    setTimeout(() => {
                        closeRegisterModal();
                        document.getElementById('loginModal').style.display = 'block';
                    }, 3000);
                } else if (data.error) {
                    document.getElementById('errorMessage').innerText = data.error;
                }
            })
            .catch(error => console.error('Error:', error));
        }

        function openLoginRequiredModal() {
            document.getElementById('loginRequiredModal').style.display = 'block';
        }

        function closeLoginRequiredModal() {
            document.getElementById('loginRequiredModal').style.display = 'none';
        }
    </script>
</head>
<body>
    <header id="header">
        <nav>
            <a href="index.php" class="logo">
                <img src="images/logo.png" alt="TECH WRLD BOOKSHOP" height="100">
            </a>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                    <li><button class="login-button" id="loginBtn">Login</button></li>

            </ul>
        </nav>
    </header>

    <section class="hero">
        <div class="container">
            <h1>Welcome to TECH WRLD BOOKSHOP</h1>
            <p>Discover a world of knowledge, imagination, and adventure in our curated collection of books and tech gadgets. Your journey into literature and innovation starts here.</p>
            <a href="about.php" class="cta-button">Learn More About Us</a>
            <a href="#" class="button shop-now-btn" onclick="showLoginRequired(event)">Shop Now</a>
        </div>
    </section>

    <section class="featured-books section">
        <div class="container">
            <h2>Featured Books</h2>
            <div class="preview">
                <div class="preview-item">
                    <img src="images/computer-science.jpg" alt="Computer Science" />
                    <h3>Computer Science</h3>
                    <p>Discussing algorithms, programming, and sequential and parallel processing.</p>
                </div>
                <div class="preview-item">
                    <img src="images/database-concepts.jpg" alt="Database Concepts" />
                    <h3>Database Concepts</h3>
                    <p>The book discusses concepts, principles, design, implementation, and management issues of databases.</p>
                </div>
                <div class="preview-item">
                    <img src="images/code-complete.jpg" alt="Code Complete" />
                    <h3>Code Complete</h3>
                    <p>Extensive exploration of clean coding principles and agile practices.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="features-section section">
        <div class="container">
            <h2>Our Features</h2>
            <div class="features">
                <div class="feature">
                    <div class="feature-icon">📚</div>
                    <h3>Vast Selection</h3>
                    <p>From classics to contemporary, find the perfect book for every reader.</p>
                </div>
                <div class="feature">
                    <div class="feature-icon">💻</div>
                    <h3>Tech Gadgets</h3>
                    <p>Enhance your reading experience with our curated tech accessories.</p>
                </div>
                <div class="feature">
                    <div class="feature-icon">🌟</div>
                    <h3>Expert Recommendations</h3>
                    <p>Get personalized suggestions from our knowledgeable staff.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="reviews-section section">
        <div class="container">
            <h2>Customer Reviews</h2>
            <div class="reviews">
                <div class="review-item">
                    <div class="review-icon">⭐⭐⭐⭐⭐</div>
                    <h3>Walter Sibiya</h3>
                    <p>"A fantastic selection of books! I found everything I was looking for and more."</p>
                </div>
                <div class="review-item">
                    <div class="review-icon">⭐⭐⭐⭐</div>
                    <h3>Robson Nkuna</h3>
                    <p>"The tech gadgets are top-notch! Highly recommend for any tech enthusiast."</p>
                </div>
                <div class="review-item">
                    <div class="review-icon">⭐⭐⭐⭐⭐</div>
                    <h3>Naledi Mamatela</h3>
                    <p>"Great customer service and a wonderful atmosphere. Will definitely return!"</p>
                </div>
            </div>
        </div>
    </section>

    <section class="cta-section section" style="background-color: var(--color-primary); color: white; text-align: center;">
        <div class="container">
            <h2>Get in Touch</h2>
            <p>Have questions or need assistance? We're here to help!</p>
            <a href="contact.php" class="cta-button" style="background-color: white; color: var(--color-primary);">Contact Us</a>
        </div>
    </section>

    <div id="loginModal" class="modal">
        <div class="modal-content">
            <span class="close" id="closeLogin">&times;</span>
            <h2>Login</h2>
            <?php if ($error): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>
            <form id="modalLoginForm" action="index.php" method="POST">
                <div class="form-group">
                    <label for="modalUsername">Username</label>
                    <input type="text" name="username" id="modalUsername" placeholder="Enter your username" required>
                </div>
                <div class="form-group">
                    <label for="modalPassword">Password</label>
                    <input type="password" name="password" id="modalPassword" placeholder="Enter your password" required>
                </div>
                <button type="submit" name="login" class="button">Login</button>
                <a href="#" class="register-link" onclick="openRegisterModal(event)">Don't have an account? Register here</a>
            </form>
        </div>
    </div>

    <div id="registerModal" class="modal" style="display:none;">
        <div class="modal-content">
            <span class="close" id="closeRegister" onclick="closeRegisterModal()">&times;</span>
            <h2>Register</h2>
            <div id="errorMessage" class="error-message"></div>
            <div id="successMessage" class="success-message"></div>
            <form id="registerForm" onsubmit="submitRegistrationForm(event)">
                <div class="form-group">
                    <label for="regUsername">Username</label>
                    <input type="text" name="regUsername" id="regUsername" placeholder="Choose a username" required>
                </div>
                <div class="form-group">
                    <label for="regEmail">Email</label>
                    <input type="email" name="regEmail" id="regEmail" placeholder="Enter your email" required>
                </div>
                <div class="form-group">
                    <label for="regPassword">Password</label>
                    <input type="password" name="regPassword" id="regPassword" placeholder="Choose a password" required>
                </div>
                <div class="form-group">
                    <label for="regConfirmPassword">Confirm Password</label>
                    <input type="password" name="regConfirmPassword" id="regConfirmPassword" placeholder="Confirm your password" required>
                </div>
                <button type="submit" class="button">Register</button>
            </form>
        </div>
    </div>

    <div id="loginRequiredModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeLoginRequiredModal()">&times;</span>
            <h2>Access Denied</h2>
            <p>A login is required to proceed.</p>
            <button class="button" onclick="openLoginFromRequired()">Login Now</button>
        </div>
    </div>

    <div id="registrationSuccessModal" class="modal">
        <div class="modal-content">
            <div class="success-message">
                <i class="fas fa-check-circle"></i>
                <h2>Registration Successful!</h2>
                <p>Your account has been created successfully.</p>
                <button class="button" onclick="closeRegSuccessModal(); openLoginModal();">Proceed to Login</button>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>

    <script>
        var loginModal = document.getElementById("loginModal");
        var registerModal = document.getElementById("registerModal");
        var closeLogin = document.getElementById("closeLogin");
        var closeRegister = document.getElementById("closeRegister");
        var loginBtn = document.getElementById("loginBtn");

        loginBtn.onclick = function(event) {
            event.preventDefault();
            loginModal.style.display = "block";
        }

        closeLogin.onclick = function() {
            loginModal.style.display = "none";
        }

        closeRegister.onclick = function() {
            registerModal.style.display = "none";
        }

        window.onclick = function(event) {
            var loginRequiredModal = document.getElementById('loginRequiredModal');
            if (event.target == loginModal) {
                loginModal.style.display = "none";
            } else if (event.target == registerModal) {
                closeRegisterModal();
            } else if (event.target == loginRequiredModal) {
                closeLoginRequiredModal();
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            // Get all "Shop Now" buttons
            var shopNowButtons = document.querySelectorAll('.shop-now-btn');
            shopNowButtons.forEach(function(button) {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    openLoginRequiredModal();
                });
            });

            // Add close button functionality for login required modal
            document.getElementById('closeLoginRequired').addEventListener('click', closeLoginRequiredModal);
        });

        function showLoginRequired(event) {
            event.preventDefault(); // Prevent the default link behavior
            document.getElementById('loginRequiredModal').style.display = 'block';
        }

        function closeLoginRequiredModal() {
            document.getElementById('loginRequiredModal').style.display = 'none';
        }

        function openLoginFromRequired() {
            closeLoginRequiredModal();
            document.getElementById('loginModal').style.display = 'block';
        }

        function handleRegistration(event) {
            event.preventDefault();
            
            const form = event.target;
            const formData = new FormData(form);
            
            // Close registration modal
            document.getElementById('registerModal').style.display = 'none';
            
            // Show success modal
            document.getElementById('registrationSuccessModal').style.display = 'block';
            
            // Reset form
            form.reset();
        }

        function closeRegSuccessModal() {
            document.getElementById('registrationSuccessModal').style.display = 'none';
        }

        function openLoginModal() {
            document.getElementById('loginModal').style.display = 'block';
        }

        // Add this to your existing window.onclick handler
        window.onclick = function(event) {
            const regSuccessModal = document.getElementById('registrationSuccessModal');
            if (event.target == regSuccessModal) {
                regSuccessModal.style.display = 'none';
            }
            // ... your other modal handlers ...
        }

        // Add this to your DOMContentLoaded event listener
        document.addEventListener('DOMContentLoaded', function() {
            const registerForm = document.getElementById('registerForm');
            if (registerForm) {
                registerForm.addEventListener('submit', handleRegistration);
            }
        });
    </script>
</body>
</html>