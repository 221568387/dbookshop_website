<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle : 'TECH WRLD BOOKSHOP'; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --color-primary: #1e40af;
            --color-primary-light: #3b82f6;
            --color-background: #f0f4f8;
            --color-text: #1f2937;
            --color-text-light: #6b7280;
            --color-accent: #f59e0b;
        }
        body, html {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--color-background);
            color: var(--color-text);
            line-height: 1.6;
        }
        header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background-color: #2563eb;
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 1.2rem;
            width: 100%;
            transition: background-color 0.3s ease;
        }
        header.scrolled {
            background-color: rgba(30, 64, 175, 0.9);
        }
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
        }
        .logo {
            text-decoration: none;
            display: flex;
            align-items: center;
        }
        .logo img {
            height: 100px;
            width: auto;
            margin: -35px 0;
            transition: transform 0.3s ease;
        }
        .logo img:hover {
            transform: scale(1.05);
        }
        nav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            display: flex;
        }
        nav ul li {
            margin-left: 1.5rem;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: opacity 0.3s ease;
        }
        nav ul li a:hover {
            opacity: 0.8;
        }
        .login-button {
            background-color: var(--color-accent);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            display: flex;
            align-items: center;
            transition: background-color 0.3s ease;
        }
        .login-button:hover {
            background-color: #d68a00;
        }
        .login-button i {
            margin-right: 5px;
        }
        main {
            padding-top: 80px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        @media (max-width: 768px) {
            nav {
                flex-direction: column;
                align-items: flex-start;
            }
            nav ul {
                margin-top: 1rem;
            }
            nav ul li {
                margin-left: 0;
                margin-right: 1rem;
            }
        }
    </style>
</head>
<body>
    <header id="header">
        <nav>
            <a href="index.php" class="logo">
                <img src="images/logo.png" alt="TECH WRLD BOOKSHOP" height="200">
            </a>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <
    </main>
</body>
</html>