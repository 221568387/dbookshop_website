<?php
session_start();
include 'db.php';
$pageTitle = "Checkout - TECH WRLD BOOKSHOP";

// Redirect if cart is empty
if (empty($_SESSION['cart'])) {
    header('Location: shop.php');
    exit();
}

// Calculate totals
$subtotal = 0;
foreach ($_SESSION['cart'] as $item) {
    $subtotal += floatval($item['price']);
}
$vat = $subtotal * 0.15;
$shipping = 50.00;
$total = $subtotal + $vat + $shipping;

// Include the default header
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            --primary-color: #4a4e69;
            --secondary-color: #9a8c98;
            --background-color: #f2e9e4;
            --text-color: #22223b;
            --button-color: #d6a600;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--background-color);
            margin: 0;
            padding-top: 80px;
            min-height: 100vh;
        }

        header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            background-color: var(--primary-color);
            color: white;
            padding: 1rem;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .main-container {
            display: flex;
            justify-content: center;
            padding: 20px;
            gap: 30px;
            max-width: 1200px;
            margin: 20px auto;
        }

        .checkout-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            flex: 2;
        }

        .order-summary {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            flex: 1;
            height: fit-content;
        }

        h2 {
            color: var(--text-color);
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--background-color);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            color: var(--text-color);
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .summary-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }

        .summary-total {
            font-weight: bold;
            font-size: 1.2em;
            margin-top: 20px;
            border-top: 2px solid #ddd;
            padding-top: 20px;
        }

        .button {
            background-color: var(--button-color);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #b59400;
        }

        @media (max-width: 768px) {
            .main-container {
                flex-direction: column;
            }
        }

        .cart-icon {
            position: absolute;
            top: 1rem;
            right: 1rem;
            font-size: 1.5rem;
            cursor: pointer;
            color: white;
        }

        .cart-count {
            background-color: var(--secondary-color);
            color: white;
            border-radius: 50%;
            padding: 0.2rem 0.5rem;
            position: absolute;
            top: -5px;
            right: -10px;
            font-size: 0.8rem;
        }

        .success-message {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            text-align: center;
            z-index: 1000;
            min-width: 300px;
        }

        .success-icon {
            color: #4CAF50;
            font-size: 60px;
            margin-bottom: 20px;
        }

        .success-message h2 {
            color: #333;
            margin-bottom: 15px;
            border: none;
        }

        .success-message p {
            color: #666;
            margin-bottom: 20px;
        }

        .success-button {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .success-button:hover {
            background-color: var(--button-color);
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <div class="checkout-container">
            <h2>Checkout Details</h2>
            <form id="checkoutForm">
                <!-- Personal Information -->
                <div class="form-section">
                    <h3>Personal Information</h3>
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" required>
                        </div>
                    </div>
                </div>

                <!-- Delivery Information -->
                <div class="form-section">
                    <h3>Delivery Information</h3>
                    <div class="form-group">
                        <label for="address">Street Address</label>
                        <input type="text" id="address" name="address" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="city">City</label>
                            <input type="text" id="city" name="city" required>
                        </div>
                        <div class="form-group">
                            <label for="postal-code">Postal Code</label>
                            <input type="text" id="postal-code" name="postal-code" required>
                        </div>
                    </div>
                </div>

                <!-- Payment Information -->
                <div class="form-section">
                    <h3>Payment Method</h3>
                    <div class="form-group">
                        <label for="payment-method">Select Payment Method</label>
                        <select id="payment-method" name="payment-method" required>
                            <option value="">Select a payment method</option>
                            <option value="credit-card">Credit Card</option>
                            <option value="debit-card">Debit Card</option>
                            <option value="eft">EFT</option>
                        </select>
                    </div>

                    <div id="card-details">
                        <div class="form-group">
                            <label for="card-number">Card Number</label>
                            <input type="text" id="card-number" name="card-number" maxlength="16">
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="expiry-date">Expiry Date</label>
                                <input type="month" id="expiry-date" name="expiry-date">
                            </div>
                            <div class="form-group">
                                <label for="cvv">CVV</label>
                                <input type="text" id="cvv" name="cvv" maxlength="4">
                            </div>
                        </div>
                    </div>
                </div>

                <button type="button" class="button" onclick="showSuccessMessage()">Pay R<?php echo number_format($total, 2); ?></button>
            </form>
        </div>

        <div class="order-summary">
            <h2>Order Summary</h2>
            <?php foreach ($_SESSION['cart'] as $item): ?>
            <div class="summary-item">
                <span><?php echo htmlspecialchars($item['title']); ?></span>
                <span>R<?php echo number_format($item['price'], 2); ?></span>
            </div>
            <?php endforeach; ?>

            <div class="summary-item">
                <span>Subtotal:</span>
                <span>R<?php echo number_format($subtotal, 2); ?></span>
            </div>
            <div class="summary-item">
                <span>VAT (15%):</span>
                <span>R<?php echo number_format($vat, 2); ?></span>
            </div>
            <div class="summary-item">
                <span>Shipping:</span>
                <span>R<?php echo number_format($shipping, 2); ?></span>
            </div>
            <div class="summary-item summary-total">
                <span>Total:</span>
                <span>R<?php echo number_format($total, 2); ?></span>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>

    <script>
        // Show/hide card details based on payment method
        document.getElementById('payment-method').addEventListener('change', function() {
            const cardDetails = document.getElementById('card-details');
            const cardInputs = cardDetails.getElementsByTagName('input');
            
            if (this.value === 'credit-card' || this.value === 'debit-card') {
                cardDetails.style.display = 'block';
                for (let input of cardInputs) {
                    input.required = true;
                }
            } else {
                cardDetails.style.display = 'none';
                for (let input of cardInputs) {
                    input.required = false;
                }
            }
        });

        // Add new success message function
        function showSuccessMessage() {
            // Basic form validation
            const form = document.getElementById('checkoutForm');
            if (!form.checkValidity()) {
                form.reportValidity();
                return;
            }

            // Show success message
            document.getElementById('overlay').style.display = 'block';
            document.getElementById('successMessage').style.display = 'block';
            
            // Clear cart
            fetch('clear_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            // Redirect after 3 seconds
            setTimeout(() => {
                window.location.href = 'shop.php';
            }, 3000);
        }
    </script>

    <div class="overlay" id="overlay"></div>
    <div class="success-message" id="successMessage">
        <i class="fas fa-check-circle success-icon"></i>
        <h2>Thank You for Your Purchase!</h2>
        <p>A receipt has been sent to your email.</p>
        <button class="success-button" onclick="window.location.href='shop.php'">Continue Shopping</button>
    </div>
</body>
</html>
