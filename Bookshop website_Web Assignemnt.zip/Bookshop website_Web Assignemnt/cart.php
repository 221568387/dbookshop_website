<?php
session_start();
$pageTitle = "Your Cart - TECH WRLD BOOKSHOP";
include 'header.php'; // Include the default header

// Retrieve the cart items from the session
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$total = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
</head>
<body>
    <main>
        <h1><?php echo $pageTitle; ?></h1>
        <?php if (empty($cart)): ?>
            <p>Your cart is empty.</p>
        <?php else: ?>
            <ul>
                <?php foreach ($cart as $item): ?>
                    <li><?php echo htmlspecialchars($item['title']); ?> - R<?php echo number_format($item['price'], 2); ?></li>
                    <?php $total += $item['price']; ?>
                <?php endforeach; ?>
            </ul>
            <p>Total: R<?php echo number_format($total, 2); ?></p>
        <?php endif; ?>
    </main>

    <?php include 'footer.php'; ?>
</body>
</html>
